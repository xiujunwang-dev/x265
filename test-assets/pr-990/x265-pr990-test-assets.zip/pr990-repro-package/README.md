# x265 PR #990 Test Inputs and Records

This archive contains the inputs and records used for the ARM64 measurements and the 36 RDOQ output checks described in PR #990. It does not contain x265 binaries.

## ARM64 `Quant::rdoQuant` timing

The source videos are included under `inputs/real/`:

| Input | Source file | Format | Frames converted | Converted Y4M SHA-256 |
| --- | --- | --- | ---: | --- |
| Portrait | `portrait-source.mp4` (`dst.mp4`) | 544x960, 25 fps, yuv420p | 182 | MP4: `c4b0968a4cfea40f43f1065c7465d88ec957c61fded1346a57a5f537442504c9`; Y4M: `d624abe16068e0796651a5355841122633d0814ebff2378e11c14d214bd5a14e` |
| HD | `hd-source.mp4` (`lols8_1920x1080_60_5000K_1080_2000_x264.mp4`) | 1920x1080, 30 fps, yuv420p | 180 | MP4: `c4f3e66b66e37b2f0301f913848a86c593ec4dbbff8df314af65981dd7153533`; Y4M: `c89926722dd011219ff9481725726af1bc11d1675e28fe22277f27a5baedbb01` |

Convert each clip to Y4M (replace `SOURCE` and `FRAMES` for each row above):

```sh
ffmpeg -nostdin -y -v error -i SOURCE -frames:v FRAMES \
  -pix_fmt yuv420p -f yuv4mpegpipe OUTPUT.y4m
```

The profiler encoded the first 60 frames of each Y4M. It ran this command with both the baseline and candidate instrumented ARM64 builds, for five paired repetitions per clip, alternating which build ran first:

```sh
x265 --input INPUT.y4m --frames 60 --preset medium --crf 28 \
  --keyint 48 --min-keyint 1 --no-scenecut --bframes 3 --rdoq-level 2 \
  --pools none --frame-threads 1 --no-wpp --no-info --no-progress --hash 1 \
  --output OUTPUT.hevc
```

`results/function-profile-summary.json` contains the medians and paired-run counts. `results/function-profile-runs.jsonl` contains the raw per-run profiles and output hashes.

## 36 output checks

`inputs/rdoq-checks/` contains the 12 raw YUV inputs used by the suite: 8-, 10-, and 12-bit versions of i420, i422, i444, and i400. Each input is 192x128 at 30 fps for 32 frames. They were generated from FFmpeg `testsrc2=size=192x128:rate=30`, with the first four frames filled gray.

Common x265 arguments for each case:

```sh
x265 --input INPUT.yuv --input-res 192x128 --fps 30 \
  --input-depth DEPTH --output-depth DEPTH --input-csp CSP --frames 32 \
  --preset medium --rd 4 --pools none --frame-threads 1 --no-wpp \
  --no-info --no-progress --hash 1 CASE_OPTIONS --output OUTPUT.hevc
```

The 36 cases were:

- For every bit-depth/chroma pair (12 pairs), run both `--psy-rdoq 0 --qp 22 --rdoq-level 1` and `--psy-rdoq 2 --qp 37 --rdoq-level 2` (24 cases).
- For each bit depth, run i420 scaling-list (`--scaling-list default --psy-rdoq 2 --qp 28 --rdoq-level 2`), i444 intra/no-signhide/transform-skip (`--keyint 1 --bframes 0 --no-signhide --tskip --qp 18 --rdoq-level 2`), i420 C path (`--asm 0 --psy-rdoq 2 --qp 32 --rdoq-level 2`), and i444 intra psy-RDOQ (`--keyint 1 --bframes 0 --psy-rdoq 2 --qp 32 --rdoq-level 2`) (12 cases).

For each case, the baseline, RDOQ shadow build, and candidate bitstreams had matching SHA-256 values. The shadow build also compared the original and changed RDOQ return value and coefficient output on every invocation.

The original profiler, validation harness, and recorded result table are included under `scripts/` and `results/` for reference. The original scripts contain paths from the test machine; the commands above document the relevant encoder arguments independently of those paths.
