import pathlib, subprocess, concurrent.futures
ROOT = pathlib.Path(__file__).resolve().parent

def build(item):
    kind, depth = item
    dest = pathlib.Path('/tmp') / f'quant-port-{kind}-arm{depth}'
    src = ROOT.parents[1] / 'x265-rdoq-baseline-20261008' if kind == 'baseline' else ROOT / kind
    args = ['cmake', '-S', str(src / 'source'), '-B', str(dest), '-G', 'Ninja',
            '-DCMAKE_OSX_ARCHITECTURES=arm64', '-DENABLE_SVE=OFF', '-DENABLE_SVE2=OFF',
            '-DENABLE_SVE2_BITPERM=OFF', '-DCMAKE_BUILD_TYPE=Release', '-DENABLE_SHARED=OFF',
            '-DCHECKED_BUILD=' + ('ON' if 'shadow' in kind else 'OFF'),
            '-DHIGH_BIT_DEPTH=' + ('ON' if depth > 8 else 'OFF'),
            '-DMAIN12=' + ('ON' if depth == 12 else 'OFF')]
    with (ROOT / f'{kind}-{depth}-build.log').open('w') as log:
        subprocess.run(args, check=True, stdout=log, stderr=subprocess.STDOUT)
        subprocess.run(['cmake', '--build', str(dest), '-j', '4'], check=True, stdout=log, stderr=subprocess.STDOUT)
    print(f'BUILT {kind} {depth}', flush=True)

if __name__ == '__main__':
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        list(pool.map(build, [(k, d) for d in (8, 10, 12) for k in ('rdoq-shadow', 'dequant-shadow', 'baseline')]
                      + [('rdoq', 8), ('dequant', 8)]))
