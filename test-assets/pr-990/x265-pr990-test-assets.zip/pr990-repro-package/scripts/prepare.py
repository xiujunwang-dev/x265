import pathlib, subprocess, tarfile, io, difflib

ROOT = pathlib.Path(__file__).resolve().parent
BASE = ROOT.parents[1] / 'x265-rdoq-baseline-20261008'
archive = subprocess.check_output(['git', '-C', str(BASE), 'archive', 'HEAD'])
original = (BASE / 'source/common/quant.cpp').read_text()
start = original.index('template <uint32_t log2TrSize>\nuint32_t Quant::rdoQuant(')
end = original.index('\nuint32_t Quant::getSigCtxInc', start)
reference = original[start:end].replace('Quant::rdoQuant(', 'Quant::rdoQuantReference(', 1)

stats = '''
namespace {
struct PortStats {
    unsigned long long rdo[4][2][3], dequant[4], shortened[4], skipped[4];
    PortStats() { memset(this, 0, sizeof(*this)); }
    ~PortStats() {
        for (int i = 0; i < 4; i++) {
            for (int p = 0; p < 2; p++) for (int s = 0; s < 3; s++)
                if (rdo[i][p][s]) fprintf(stderr, "PORT RDOQ depth=%d size=%d psy=%d scan=%d calls=%llu\\n", X265_DEPTH, 4 << i, p, s, rdo[i][p][s]);
            if (dequant[i]) fprintf(stderr, "PORT DEQUANT depth=%d size=%d calls=%llu shortened=%llu skipped=%llu\\n", X265_DEPTH, 4 << i, dequant[i], shortened[i], skipped[i]);
        }
    }
} portStats;
}
'''

for kind in ('rdoq', 'dequant'):
    dest = ROOT / kind
    dest.mkdir(exist_ok=True)
    with tarfile.open(fileobj=io.BytesIO(archive)) as tf:
        tf.extractall(dest)
    code = original
    if kind == 'rdoq':
        a = code.index('    /* Initialize the uncoded distortion for every coefficient.')
        b = code.index('    /* iterate over coding groups in reverse scan order */', a)
        code = code[:a] + '''    /* Trailing zero groups have the same distortion in every candidate,
     * including CBF=0, so omit that common additive cost. Coefficients remain
     * in raster order; use the existing 4x4-group primitives. */
    for (int cg = 0; cg <= cgLastScanPos; cg++)
    {
        const uint32_t group = scanCG[cg];
        const uint32_t base = ((group >> log2TrSizeCG) * trSize +
                               (group & (cgStride - 1))) * 4;
        if (usePsyMask)
            primitives.cu[log2TrSize - 2].psyRdoQuant(m_resiDctCoeff, sourceDct, costUncoded, &totalUncodedCost, &totalRdCost, &psyScale, base);
        else
            primitives.cu[log2TrSize - 2].nonPsyRdoQuant(m_resiDctCoeff, costUncoded, &totalUncodedCost, &totalRdCost, base);
    }
    if (usePsyMask)
    {
        const int64_t dcPsyCost = PSYVALUE(sourceDct[0] - m_resiDctCoeff[0]);
        costUncoded[0] += dcPsyCost;
        totalUncodedCost += dcPsyCost;
        totalRdCost += dcPsyCost;
    }
''' + code[b:]
    else:
        old = '        primitives.dequant_normal(coeff, m_resiDctCoeff, numCoeff, scale, shift);'
        code = code.replace(old, '''        int last = numCoeff;
        if (sizeIdx)
        {
            while (last && !coeff[last - 1])
                last--;
            last = (last + 15) & ~15;
        }
        if (last)
            primitives.dequant_normal(coeff, m_resiDctCoeff, last, scale, shift);
        memset(m_resiDctCoeff + last, 0, (numCoeff - last) * sizeof(int16_t));''')
    (dest / 'source/common/quant.cpp').write_text(code)
    patch = ''.join(difflib.unified_diff(original.splitlines(True), code.splitlines(True), fromfile='a/source/common/quant.cpp', tofile='b/source/common/quant.cpp'))
    (ROOT / (kind + '.patch')).write_text(patch)
    # Shadow builds compare each invocation with the actual unmodified function.
    shadow = ROOT / (kind + '-shadow')
    shadow.mkdir(exist_ok=True)
    with tarfile.open(fileobj=io.BytesIO(archive)) as tf:
        tf.extractall(shadow)
    code = code.replace('using namespace X265_NS;', 'using namespace X265_NS;\n' + stats)
    if kind == 'rdoq':
        # Keep the public dispatch on a wrapper, with baseline and experiment isolated.
        code = code.replace('Quant::rdoQuant(', 'Quant::rdoQuantPort(', 1)
        wrapper = '''
template <uint32_t log2TrSize>
uint32_t Quant::rdoQuant(const CUData& cu, int16_t* dstCoeff, TextType ttype, uint32_t absPartIdx, bool usePsy, const pixel* fenc, uint32_t fencStride)
{
    ALIGN_VAR_32(int16_t, expected[1 << (log2TrSize * 2)]);
    uint32_t ref = rdoQuantReference<log2TrSize>(cu, expected, ttype, absPartIdx, usePsy, fenc, fencStride);
    uint32_t got = rdoQuantPort<log2TrSize>(cu, dstCoeff, ttype, absPartIdx, usePsy, fenc, fencStride);
    if (ref != got || memcmp(expected, dstCoeff, sizeof(expected))) {
        fprintf(stderr, "PORT RDOQ MISMATCH depth=%d size=%d psy=%d sig=%u/%u\\n", X265_DEPTH, 1 << log2TrSize, usePsy, ref, got);
        abort();
    }
    TUEntropyCodingParameters cp;
    cu.getTUEntropyCodingParameters(cp, absPartIdx, log2TrSize, ttype == TEXT_LUMA);
    portStats.rdo[log2TrSize - 2][usePsy][cp.scanType]++;
    return got;
}
'''
        code += '\n' + reference + wrapper
        header = (shadow / 'source/common/quant.h').read_text()
        declstart = header.index('    template <uint32_t log2TrSize>\n    uint32_t rdoQuant(')
        declend = header.index('\n\n', declstart)
        decl = header[declstart:declend]
        header = header[:declend] + '\n' + decl.replace('rdoQuant(', 'rdoQuantReference(') + '\n' + decl.replace('rdoQuant(', 'rdoQuantPort(') + header[declend:]
        (shadow / 'source/common/quant.h').write_text(header)
    else:
        code = code.replace('        int last = numCoeff;', '''        ALIGN_VAR_32(int16_t, expected[32 * 32]);
        primitives.dequant_normal(coeff, expected, numCoeff, scale, shift);
        memset(m_resiDctCoeff, 0x5a, numCoeff * sizeof(int16_t));
        int last = numCoeff;''')
        needle = '        memset(m_resiDctCoeff + last, 0, (numCoeff - last) * sizeof(int16_t));'
        code = code.replace(needle, needle + '''
        if (memcmp(expected, m_resiDctCoeff, numCoeff * sizeof(int16_t))) {
            fprintf(stderr, "PORT DEQUANT MISMATCH depth=%d size=%d last=%d\\n", X265_DEPTH, 1 << log2TrSize, last);
            abort();
        }
        portStats.dequant[sizeIdx]++;
        portStats.shortened[sizeIdx] += last < numCoeff;
        portStats.skipped[sizeIdx] += numCoeff - last;''')
    (shadow / 'source/common/quant.cpp').write_text(code)
print('Prepared independent ports and per-call shadow validation trees')
