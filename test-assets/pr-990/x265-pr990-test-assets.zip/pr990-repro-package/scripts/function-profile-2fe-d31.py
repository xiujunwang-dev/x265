import hashlib
import json
import pathlib
import re
import statistics
import subprocess

ROOT = pathlib.Path(__file__).resolve().parent
TMP = pathlib.Path('/tmp/quant-port-function-profile')
TMP.mkdir(exist_ok=True)
INPUTS = {
    'portrait': (pathlib.Path('/tmp/sigctx-real-inputs/portrait.y4m'), 60),
    'hd': (pathlib.Path('/tmp/sigctx-real-inputs/hd.y4m'), 60),
}
TARGETS = {
    '2fe-rdoq': {
        'function': 'Quant::rdoQuant',
        'baseline': pathlib.Path('/tmp/qprofbuild-rdoq-base/x265'),
        'port': pathlib.Path('/tmp/qprofbuild-rdoq-port/x265'),
    },
    'd31-invtransform': {
        'function': 'Quant::invtransformNxN',
        'baseline': pathlib.Path('/tmp/qprofbuild-dequant-base/x265'),
        'port': pathlib.Path('/tmp/qprofbuild-dequant-port/x265'),
    },
}
PROFILE_RE = re.compile(
    r'FUNCTION_PROFILE function=(.*?) size=(\d+) calls=(\d+) ticks=(\d+) ns_per_call=([0-9.]+)'
)
REPEATS = 5
raw_path = ROOT / 'function-profile-2fe-d31-runs.jsonl'
raw_path.write_text('')
rows = []

for input_name, (input_path, frames) in INPUTS.items():
    for target_name, target in TARGETS.items():
        hashes = set()
        for repeat in range(REPEATS):
            order = ('baseline', 'port') if repeat % 2 == 0 else ('port', 'baseline')
            for kind in order:
                output_path = TMP / f'{input_name}-{target_name}-{kind}-{repeat}.hevc'
                command = [
                    str(target[kind]), '--input', str(input_path), '--frames', str(frames),
                    '--preset', 'medium', '--crf', '28', '--keyint', '48', '--min-keyint', '1',
                    '--no-scenecut', '--bframes', '3', '--rdoq-level', '2',
                    '--pools', 'none', '--frame-threads', '1', '--no-wpp',
                    '--no-info', '--no-progress', '--hash', '1', '--output', str(output_path),
                ]
                result = subprocess.run(command, check=True, stdout=subprocess.PIPE,
                                        stderr=subprocess.STDOUT, text=True)
                if f'encoded {frames} frames' not in result.stdout:
                    raise RuntimeError(f'{input_name} {target_name} {kind} repeat={repeat}: encode failed')

                profiles = {}
                for function, size, calls, ticks, ns_per_call in PROFILE_RE.findall(result.stdout):
                    if function != target['function']:
                        raise RuntimeError(f'unexpected profile function: {function}')
                    profiles[int(size)] = {
                        'calls': int(calls), 'ticks': int(ticks), 'ns_per_call': float(ns_per_call),
                    }
                if not profiles:
                    raise RuntimeError(f'{input_name} {target_name} {kind} repeat={repeat}: no profile data')

                digest = hashlib.sha256(output_path.read_bytes()).hexdigest()
                hashes.add(digest)
                row = {
                    'input': input_name, 'target': target_name, 'function': target['function'],
                    'repeat': repeat, 'kind': kind, 'sha256': digest, 'profiles': profiles,
                }
                rows.append(row)
                serializable = dict(row)
                serializable['profiles'] = {str(size): values for size, values in profiles.items()}
                with raw_path.open('a') as raw_file:
                    raw_file.write(json.dumps(serializable) + '\n')
                print(f'{input_name} {target_name} {kind} repeat={repeat} sha256={digest}', flush=True)

        if len(hashes) != 1:
            raise AssertionError(f'{input_name} {target_name}: baseline and port outputs differ')

summary = []
for input_name in INPUTS:
    for target_name, target in TARGETS.items():
        group = [row for row in rows if row['input'] == input_name and row['target'] == target_name]
        sizes = sorted(set.intersection(*(set(row['profiles']) for row in group)))
        for size in sizes:
            baseline = [row['profiles'][size] for row in group if row['kind'] == 'baseline']
            port = [row['profiles'][size] for row in group if row['kind'] == 'port']
            if {item['calls'] for item in baseline} != {item['calls'] for item in port}:
                raise AssertionError(f'{input_name} {target_name} size={size}: call counts differ')

            base_ns = [item['ns_per_call'] for item in baseline]
            port_ns = [item['ns_per_call'] for item in port]
            paired_speedups = [
                (baseline[i]['ns_per_call'] / port[i]['ns_per_call'] - 1) * 100
                for i in range(REPEATS)
            ]
            summary.append({
                'input': input_name, 'target': target_name, 'function': target['function'],
                'size': size, 'calls_per_run': baseline[0]['calls'],
                'baseline_ns_per_call_median': statistics.median(base_ns),
                'port_ns_per_call_median': statistics.median(port_ns),
                'median_speedup_percent': (statistics.median(base_ns) / statistics.median(port_ns) - 1) * 100,
                'paired_speedup_range_percent': [min(paired_speedups), max(paired_speedups)],
                'paired_positive_runs': sum(value > 0 for value in paired_speedups),
                'paired_total_runs': REPEATS,
            })

result = {'repeats': REPEATS, 'frames_per_input': 60, 'runs': len(rows), 'summary': summary}
summary_path = ROOT / 'function-profile-2fe-d31-summary.json'
summary_path.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(summary, indent=2), flush=True)
