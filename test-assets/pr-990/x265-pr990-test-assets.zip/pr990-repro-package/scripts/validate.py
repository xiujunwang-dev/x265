import pathlib, subprocess, hashlib, json, re, concurrent.futures
ROOT = pathlib.Path(__file__).resolve().parent
INPUT = ROOT / 'inputs'
FRAMES = 32
FORMATS = [(d, c) for d in (8, 10, 12) for c in ('i420', 'i422', 'i444', 'i400')]

def generate(fmt):
    depth, csp = fmt
    pix = {'i420': 'yuv420p', 'i422': 'yuv422p', 'i444': 'yuv444p', 'i400': 'gray'}[csp]
    if depth > 8:
        pix = ('gray' if csp == 'i400' else pix) + str(depth) + 'le'
    path = INPUT / f'{depth}-{csp}.yuv'
    if path.exists():
        return
    subprocess.run(['ffmpeg', '-nostdin', '-y', '-v', 'error', '-f', 'lavfi', '-i',
                    'testsrc2=size=192x128:rate=30', '-vf', r'drawbox=x=0:y=0:w=iw:h=ih:color=gray:t=fill:enable=lt(n\,4)',
                    '-frames:v', str(FRAMES), '-pix_fmt', pix, '-f', 'rawvideo', str(path)], check=True)

CASES = []
for depth, csp in FORMATS:
    for psy, qp, rdo in [(0, 22, 1), (2, 37, 2)]:
        CASES.append((depth, csp, f'p{psy}-q{qp}-r{rdo}', ['--psy-rdoq', str(psy), '--qp', str(qp), '--rdoq-level', str(rdo)]))
for depth in (8, 10, 12):
    CASES += [
        (depth, 'i420', 'scaling', ['--scaling-list', 'default', '--psy-rdoq', '2', '--qp', '28', '--rdoq-level', '2']),
        (depth, 'i444', 'intra-nohide-tskip', ['--keyint', '1', '--bframes', '0', '--no-signhide', '--tskip', '--qp', '18', '--rdoq-level', '2']),
        (depth, 'i420', 'c-path', ['--asm', '0', '--psy-rdoq', '2', '--qp', '32', '--rdoq-level', '2']),
        (depth, 'i444', 'intra-psy', ['--keyint', '1', '--bframes', '0', '--psy-rdoq', '2', '--qp', '32', '--rdoq-level', '2']),
    ]

def run(case):
    depth, csp, suffix, extra = case
    name = f'{depth}-{csp}-{suffix}'
    rows = []
    for kind in ('rdoq-shadow', 'dequant-shadow', 'baseline'):
        binary = f'/tmp/quant-port-{kind}-arm{depth}/x265'
        if kind == 'baseline' and depth < 12 and not pathlib.Path(binary).exists():
            binary = f'/tmp/x265-rdoq-v2-baseline{depth}/x265'
        output = ROOT / f'{name}-{kind}.hevc'
        cmd = [binary, '--input', str(INPUT / f'{depth}-{csp}.yuv'), '--input-res', '192x128', '--fps', '30',
               '--input-depth', str(depth), '--output-depth', str(depth), '--input-csp', csp,
               '--frames', str(FRAMES), '--preset', 'medium', '--rd', '4', '--pools', 'none', '--frame-threads', '1',
               '--no-wpp', '--no-info', '--no-progress', '--hash', '1', *extra, '--output', str(output)]
        logpath = ROOT / f'{name}-{kind}.log'
        if not (output.exists() and logpath.exists() and f'encoded {FRAMES} frames' in logpath.read_text()):
            with logpath.open('w') as log:
                subprocess.run(cmd, check=True, stdout=log, stderr=subprocess.STDOUT)
        logtext = logpath.read_text()
        assert f'encoded {FRAMES} frames' in logtext
        assert 'MISMATCH' not in logtext
        stats = [line for line in logtext.splitlines() if line.startswith('PORT ')]
        assert stats or kind == 'baseline' or (kind == 'dequant-shadow' and suffix == 'scaling'), name
        rows.append(dict(kind=kind, command=cmd, sha256=hashlib.sha256(output.read_bytes()).hexdigest(), stats=stats))
    assert len({row['sha256'] for row in rows}) == 1, name
    print(f'PASS {name}', flush=True)
    return dict(case=name, frames=FRAMES, runs=rows)

if __name__ == '__main__':
    INPUT.mkdir(exist_ok=True)
    for fmt in FORMATS:
        generate(fmt)
    # Failures retain logs and completed rows for diagnosis.
    results = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        for row in pool.map(run, CASES):
            results.append(row)
            (ROOT / 'results.json').write_text(json.dumps(results, indent=2) + '\n')
    print(f'All {len(results)} paired cases passed.', flush=True)
